import type { UserAgent } from "../utils/userAgent";
declare function windowUserAgent(): UserAgent;
export { windowUserAgent };
