declare function showReconnectDialog(delay: number): void;
declare function hideReconnectDialog(): void;
export { showReconnectDialog, hideReconnectDialog };
