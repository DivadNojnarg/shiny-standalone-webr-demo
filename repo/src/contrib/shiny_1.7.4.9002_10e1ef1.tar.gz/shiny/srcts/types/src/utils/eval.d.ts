declare const indirectEval: typeof eval;
export { indirectEval };
