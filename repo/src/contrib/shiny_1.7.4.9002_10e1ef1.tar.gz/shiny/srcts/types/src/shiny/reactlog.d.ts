declare function initReactlog(): void;
export { initReactlog };
