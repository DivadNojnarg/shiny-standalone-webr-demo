global <- "ABC"
global_wd <- getwd()
