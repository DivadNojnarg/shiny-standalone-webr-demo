# Contributing to data.table

Contribution guidelines are on [**Contributing page**](https://github.com/Rdatatable/data.table/wiki/Contributing) on the project's wiki:

* so it can be revised easily in one place by anyone
* so that revsions do not trigger Continuous Integration checks
