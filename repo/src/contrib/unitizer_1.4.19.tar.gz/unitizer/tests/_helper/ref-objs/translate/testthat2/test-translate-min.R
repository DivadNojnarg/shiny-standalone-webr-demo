# Minimal translation
test_that("simple tests", {
  expect_equal(fun0(a), 1:10)
})

