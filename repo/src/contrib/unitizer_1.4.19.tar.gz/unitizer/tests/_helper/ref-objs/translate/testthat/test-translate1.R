# for translate unitizer tests

expect_equal(fun0(a), 1:10)   # blah blah
expect_true(fun1(a))

# a test for errors

expect_error(stop("hello"))

random_function()
