z <- 24
unitizer_sect("A", {
  a <- 42
  a + 1
  a + 2
})
unitizer_sect("B", {
  b <- 25
  bb <- 26
  b + 1
  bbb <- 27
  b + 2
})

