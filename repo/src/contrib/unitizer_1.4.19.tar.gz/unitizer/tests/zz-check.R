source('aammrtf/check.R')
