Stand-in file to make sure directory is copied.

Normally would be something else.
