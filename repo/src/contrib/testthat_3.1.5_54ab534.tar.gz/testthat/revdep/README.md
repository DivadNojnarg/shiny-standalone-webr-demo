# Revdeps

## Failed to check (31)

|package      |version |error |warning |note |
|:------------|:-------|:-----|:-------|:----|
|Boom         |0.9.10  |1     |        |     |
|CausalImpact |?       |      |        |     |
|NA           |?       |      |        |     |
|ctsem        |3.7.1   |1     |        |     |
|NA           |?       |      |        |     |
|elbird       |0.2.5   |1     |        |     |
|ggPMX        |?       |      |        |     |
|NA           |?       |      |        |     |
|NA           |?       |      |        |     |
|loon.ggplot  |?       |      |        |     |
|loon.shiny   |?       |      |        |     |
|loon.tourr   |?       |      |        |     |
|NA           |?       |      |        |     |
|NA           |?       |      |        |     |
|mlrCPO       |0.3.7-4 |1     |        |     |
|nlmixr2      |?       |      |        |     |
|nlmixr2extra |?       |      |        |     |
|nlmixr2plot  |?       |      |        |     |
|NA           |?       |      |        |     |
|OpenMx       |?       |      |        |     |
|NA           |?       |      |        |     |
|rPBK         |0.2.0   |1     |        |     |
|NA           |?       |      |        |     |
|NA           |?       |      |        |     |
|SSVS         |?       |      |        |     |
|NA           |?       |      |        |     |
|NA           |?       |      |        |     |
|tidySEM      |?       |      |        |     |
|NA           |?       |      |        |     |
|vivid        |?       |      |        |     |
|NA           |?       |      |        |     |

## New problems (2)

|package      |version |error  |warning |note |
|:------------|:-------|:------|:-------|:----|
|[datagovindia](problems.md#datagovindia)|1.0.5   |       |__+1__  |     |
|[hyperSpec](problems.md#hyperspec)|0.100.0 |__+1__ |        |1    |

