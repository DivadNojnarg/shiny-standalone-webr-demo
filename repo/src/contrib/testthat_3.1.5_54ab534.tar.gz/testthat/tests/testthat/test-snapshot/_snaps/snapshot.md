# errors reset snapshots

    Code
      print(1)
    Output
      [1] 1

# skips reset snapshots

    Code
      print(1)
    Output
      [1] 1

