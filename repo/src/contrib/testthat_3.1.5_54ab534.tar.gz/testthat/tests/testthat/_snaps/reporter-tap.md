# reporter works

    1..9
    # Context Successes
    ok 1 Success
    # Context Failures
    not ok 2 Failure:1
      FALSE is not TRUE
      
      `actual`:   FALSE
      `expected`: TRUE 
    not ok 3 Failure:2a
      FALSE is not TRUE
      
      `actual`:   FALSE
      `expected`: TRUE 
      Backtrace:
       1. f()
            at reporters/tests.R:17:2
       2. testthat::expect_true(FALSE)
            at reporters/tests.R:16:7
    # Context Errors
    not ok 4 Error:1
      Error in `eval(code, test_env)`: stop
    not ok 5 errors get tracebacks
      Error in `h()`: !
      Backtrace:
       1. f()
            at reporters/tests.R:31:2
       2. g()
            at reporters/tests.R:27:7
       3. h()
            at reporters/tests.R:28:7
    # Context Skips
    ok 6 # SKIP Reason: skip
    ok 7 # SKIP Reason: empty test
    # Context Warnings
    ok 8 # WARNING def
    Backtrace:
     1. f()
          at reporters/tests.R:49:2
    ok 9 # SKIP Reason: empty test

