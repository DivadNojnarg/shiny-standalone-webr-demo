# captures expectations; doesn't produce any output

    

---

    9

