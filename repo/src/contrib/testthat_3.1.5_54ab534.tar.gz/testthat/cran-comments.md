## R CMD check results

There were no ERRORs, WARNINGs, or NOTEs.

## revdepcheck results

We checked 7097 reverse dependencies (7083 from CRAN + 14 from Bioconductor), comparing R CMD check results across CRAN and dev versions of this package. We failed to check 17 packages (listed below) but did not otherwise see any problems.

### Failed to check

* Boom         (NA)
* CausalImpact (NA)
* ctsem        (NA)
* elbird       (NA)
* ggPMX        (NA)
* loon.ggplot  (NA)
* loon.shiny   (NA)
* loon.tourr   (NA)
* mlrCPO       (NA)
* nlmixr2      (NA)
* nlmixr2extra (NA)
* nlmixr2plot  (NA)
* OpenMx       (NA)
* rPBK         (NA)
* SSVS         (NA)
* tidySEM      (NA)
* vivid        (NA)
